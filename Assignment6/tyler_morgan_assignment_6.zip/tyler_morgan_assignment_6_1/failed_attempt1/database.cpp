//Tyler Morgan
//Mar-16-2013
//UW online c++ class
//assignment 6.1
//database placeholder
//database.cpp

#include "database.h"

void Database::upsert(Account& account)
{
	//update or insert an account into the database
	return;
}

void Database::upsert(CustomerAccount& customer_account)
{
	//update or insert a customer account into database
	return;
}

void Database::upsert(Transaction& transaction)
{
	//update or insert a transaction into database
	return;
}

void Database::find(Account& account)
{
	//find an account in database
	return;
}

void Database::find(CustomerAccount& customer_account)
{
	//find a customer account in database
	return;
}

void Database::find(Transaction& transaction)
{
	//find a transaction in database
	return;
}