//Tyler Morgan
//feb-16-2013
//UW C++ online course
//Assignment 2.2
#include <string>

struct month_days
{
	char month[15];
	int days;
};

