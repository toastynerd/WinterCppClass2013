//Tyler Morgan
//feb-23-2013
//UW online C++ course
//assignment 3.2
#include <iostream>
#include <string>

void write(std::ostream& os, int value)
{
	os << value;
	return;
}

void write(std::ostream& os, float value)
{
	os << value;
	return;
}

void write(std::ostream& os, std::string value)
{
	os << value;
	return;
}
