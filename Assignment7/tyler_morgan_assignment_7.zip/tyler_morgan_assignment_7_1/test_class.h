#include "probe.h"
#include <iostream>

class TestClass
{
public:;
	TestClass();
	~TestClass();
	static Probe probe;
private:
	
};